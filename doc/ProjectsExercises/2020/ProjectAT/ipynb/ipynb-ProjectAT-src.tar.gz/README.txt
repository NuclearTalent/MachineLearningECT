This IPython notebook ProjectAT.ipynb does not require any additional
programs.
