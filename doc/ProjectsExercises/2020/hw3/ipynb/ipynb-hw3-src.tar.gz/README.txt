This IPython notebook hw3.ipynb does not require any additional
programs.
