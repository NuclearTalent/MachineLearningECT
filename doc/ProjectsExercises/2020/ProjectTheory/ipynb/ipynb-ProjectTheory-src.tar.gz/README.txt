This IPython notebook ProjectTheory.ipynb does not require any additional
programs.
