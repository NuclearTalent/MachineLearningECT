This IPython notebook hw4.ipynb does not require any additional
programs.
