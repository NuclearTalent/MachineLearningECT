This IPython notebook ProjectOwnData.ipynb does not require any additional
programs.
