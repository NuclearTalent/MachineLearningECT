This IPython notebook LogReg.ipynb does not require any additional
programs.
