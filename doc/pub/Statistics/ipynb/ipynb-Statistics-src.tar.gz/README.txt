This IPython notebook Statistics.ipynb does not require any additional
programs.
