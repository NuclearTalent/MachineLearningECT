This IPython notebook Day1.ipynb does not require any additional
programs.
